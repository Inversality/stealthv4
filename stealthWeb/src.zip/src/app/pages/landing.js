
'use client'
export default function landing() {

    return (
        <div class = "flex justify-center bg-[#0F1011] h-[100vh]">
          <div class = "flex flex-col mt-[30vh]" >
          {icons.logo}
          <Image class =" mt-[32px]  self-center" width = "170" height = "27" src = "/Stealth.png"/>
          <div class = "bg-[#3C3C3C] w-[311px] h-[55px] rounded-[8px] flex justify-center mt-[66px] border-2 border-transparent hover:border-white hover:w-[110%] hover:h[110%] hover:self-center hover:animate-[pulse_1s]">
            <div class = " flex flex-row justify-center self-center ">
            {icons.google}
            <h1 class = "pl-[16px] text-[12px] text-[#C3C3C3] hover:text-white ">Continue With Google</h1>
            </div>
          </div>
          <div class = "bg-black w-[311px] h-[55px] rounded-[8px] flex justify-center mt-[26px] border-2 border-transparent  hover:border-white hover:w-[110%] hover:h[110%] hover:self-center hover:animate-[pulse_1s]">
            <div class = " flex flex-row justify-center self-center ">
        
            <h1 class = "pl-[16px] text-[12px] text-[#C3C3C3] hover:text-white   ">Continue With Email</h1>
            </div>
          </div>
          <div class = "bg-black w-[311px] h-[55px] rounded-[8px] flex justify-center mt-[26px] border-2 border-transparent  hover:border-white hover:w-[110%] hover:h[110%] hover:self-center hover:animate-[pulse_1s]">
            <div class = " flex flex-row justify-center self-center ">
           
            <h1 class = "pl-[16px] text-[12px] text-[#C3C3C3] hover:text-white ">Continue With Phone</h1>
            </div>
          </div>
          </div>
      </div>
    );

}
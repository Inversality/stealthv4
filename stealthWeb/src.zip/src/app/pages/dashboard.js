'use client'

export default function dashboard() {

    return (
            <div class = "flex flex-col">
            <div className = "w-full h-[5vh] flex justify-center bg-[#080808]">
              <div className = "flex justify-center flex-row items-center ">
                <Image className="w-[20px] h-[20px] mr-[14px] "  src = "/dashboardlogo.png" width = "20" height = "20"/>
                <h1 className=" text-[14px] text-[#C3C3C3]">
                  Stealth
                </h1>
                <Image className="w-[12px] h-[12px]" src = "/arrow.png" width = "12" height = "12" />
                <h1 className=" text-[14px] text-[#C3C3C3] ">
                  Dashboard
                </h1>
              </div>
            </div>
            <section className="">
             
              <div className="flex flex-row  h-[95vh]">
                <div className="h-full w-[256px] bg-black flex flex-col mr-[31px] ml-[12px] mt-[26px]">
                  <div className = "flex flex-row ">
                    <div className="w-[25px] h-[25px] bg-[#00C2FF] rounded-[5px] mr-[6px]"> 
                      <h1 className="text-[12px] ">
                        CC
                      </h1>
                    </div>
                    <h1 className="text-[#C3C3C3]">
                      Stealth
                    </h1>
                    <div className="w-[4px]"/>
                    <Image src = "/arrowdown.png" className="h-[4.5px] self-center" width = "9" height = "4"/>
                    <div className="w-[71px]"/>
                    {icons.search}
                    <Image src = "/note.png" width = "18" height = "18" className=" self-center"/>
                  </div>
                  <div className="flex flex-row mt-[38px] mb-[20px]">
                    <h1 className="text-[#747474] text-[12px] mr-[8px]">
                      Platforms
                    </h1>
                    {icons.downarrow}
                  </div>
                  <div className = "flex flex-col">
                  <PlatformFolder label = "Lexi 2 Legit"
                   color = "#FFFFFF" 
                   tabs = {[
                    {
                      icon: icons.instagram, label: 'Instagram'
                   },
                  {
                    icon:  icons.youtube,
                    label: "Youtube"
                  },
                   {
                    icon:
                    icons.onlyfans,
                    label: "Onlyfans"
        
                   }]}
                  />
                 <PlatformTab
                    icon={
                        icons.instagram
                    }
                    label="Instagram"
                />
                  <PlatformFolder label = "James Charles"
                   color = "#1CFF33" 
                   tabs = {[
                    {
                      icon: icons.instagram, label: 'Instagram'
                   },
                  {
                    icon:  icons.youtube,
                    label: "Youtube"
                  },
                   {
                    icon:
                    icons.onlyfans,
                    label: "Onlyfans"
        
                   }]}
                  />
                  
                  </div>
                  
                </div>
                <div className = "h-[100%] px-[32px] pt-[17px] pb-[28px] w-full flex flex-col bg-[#0F1011]  ">
                  <div className = "mb-[22px] flex flex-row w-full " >
                    <div className="w-[233px] border-[1px] border-[#323135] h-[40px] bg-[#0E0E0F] hover:border-white flex justify-center rounded-[10px]">
                      <h1 className = "text-[#C3C3C3] hover:text-white self-center">
                        Today
                      </h1>
                    </div>
                    <div className = "grow"></div>
                    <div className="w-[233px] border-[1px] border-[#323135] h-[40px] hover:border-white bg-[#0E0E0F] flex justify-center rounded-[10px]">
                      <h1 className="text-[#C3C3C3] hover:text-white   self-center   ">
                        Demographics
                      </h1>
                    </div>
                  </div>
                  <div className="mb-[27px] w-full h-[15%] hover:border-white bg-[#0E0E0F] rounded-[10px] border-[1px] border-[#323135] flex justify-center">
                  {icons.plus}
                  </div>
                  <div className="w-full h-[43%] flex flex-row mb-[23px]">
                    <div className="bg-[#0E0E0F] border-[1px] hover:border-white border-[#323135] h-full w-[33%] mr-[5px] rounded-[10px] flex justify-center">
                    {icons.plus}
                    </div>
                    <div className="grow"/>
                    <div className="bg-[#0E0E0F]  border-[1px] hover:border-white border-[#323135] h-full  w-[33%] mr-[5px] rounded-[10px] flex justify-center">
                    {icons.plus}
                    </div>
                    <div className="grow"/>
                    <div className="bg-[#0E0E0F] border-[1px] hover:border-white border-[#323135] h-full  w-[33%] rounded-[10px] flex justify-center">
                    {icons.plus}
                    </div>
                  </div>
                  <div className = "flex flex-row w-full h-[26%]">
                    <div className="bg-[#0E0E0F] border-[1px] hover:border-white border-[#323135] h-full w-[49%] rounded-[10px] flex justify-center">
                    {icons.plus}
                    </div>
                    <div className="grow"/>
                    <div className="bg-[#0E0E0F] border-[1px] border-[#323135] hover:border-white h-full w-[49%] rounded-[10px] flex justify-center">
                    {icons.plus}
                    </div>
                  </div>
                </div>
                
          </div>
            </section>
          </div>
    );

}